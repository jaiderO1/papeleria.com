/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package views;

import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.font.TextAttribute;
import java.util.Map;
/**
 *
 * @author Jaider
 */
public class iniciar_sesion extends javax.swing.JFrame {

    Font a;
    registro vista;
    inventario vista2;
    int xMouse, yMouse;

    public iniciar_sesion() {
        initComponents();
        a = this.registrarse_label.getFont();
        this.vista = new registro();
        this.vista2 = new inventario();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel3 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        barra_tareas = new javax.swing.JPanel();
        cerrar_btn = new javax.swing.JPanel();
        cerrar_lbl = new javax.swing.JLabel();
        ingresar_button = new javax.swing.JPanel();
        jLabel5 = new javax.swing.JLabel();
        registrarse_label = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        usuarioTF = new javax.swing.JTextField();
        contraTF = new javax.swing.JPasswordField();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);
        setResizable(false);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Yu Gothic Medium", 1, 36)); // NOI18N
        jLabel1.setText("Iniciar Sesión");
        jPanel3.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 90, 370, 50));

        jPanel1.setBackground(new java.awt.Color(127, 71, 173));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setBackground(new java.awt.Color(255, 255, 255));
        jLabel7.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/Logos_Variados.png"))); // NOI18N
        jLabel7.setText("jLabel7");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -40, 360, 590));

        jPanel3.add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(440, 0, 370, 520));

        barra_tareas.setBackground(new java.awt.Color(255, 255, 255));
        barra_tareas.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        barra_tareas.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                barra_tareasMouseDragged(evt);
            }
        });
        barra_tareas.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                barra_tareasMouseEntered(evt);
            }
            public void mousePressed(java.awt.event.MouseEvent evt) {
                barra_tareasMousePressed(evt);
            }
        });

        cerrar_btn.setBackground(new java.awt.Color(127, 71, 173));
        cerrar_btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cerrar_btnMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cerrar_btnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cerrar_btnMouseExited(evt);
            }
        });

        cerrar_lbl.setFont(new java.awt.Font("Yu Gothic Medium", 1, 14)); // NOI18N
        cerrar_lbl.setForeground(new java.awt.Color(245, 250, 186));
        cerrar_lbl.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cerrar_lbl.setText("X");

        javax.swing.GroupLayout cerrar_btnLayout = new javax.swing.GroupLayout(cerrar_btn);
        cerrar_btn.setLayout(cerrar_btnLayout);
        cerrar_btnLayout.setHorizontalGroup(
            cerrar_btnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cerrar_btnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cerrar_lbl)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        cerrar_btnLayout.setVerticalGroup(
            cerrar_btnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(cerrar_btnLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(cerrar_lbl)
                .addContainerGap(31, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout barra_tareasLayout = new javax.swing.GroupLayout(barra_tareas);
        barra_tareas.setLayout(barra_tareasLayout);
        barra_tareasLayout.setHorizontalGroup(
            barra_tareasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barra_tareasLayout.createSequentialGroup()
                .addComponent(cerrar_btn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 471, Short.MAX_VALUE))
        );
        barra_tareasLayout.setVerticalGroup(
            barra_tareasLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(barra_tareasLayout.createSequentialGroup()
                .addComponent(cerrar_btn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel3.add(barra_tareas, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 510, 40));

        ingresar_button.setBackground(new java.awt.Color(127, 71, 173));
        ingresar_button.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        ingresar_button.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ingresar_buttonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                ingresar_buttonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                ingresar_buttonMouseExited(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Yu Gothic Medium", 1, 13)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(245, 250, 186));
        jLabel5.setText("Ingresar");

        javax.swing.GroupLayout ingresar_buttonLayout = new javax.swing.GroupLayout(ingresar_button);
        ingresar_button.setLayout(ingresar_buttonLayout);
        ingresar_buttonLayout.setHorizontalGroup(
            ingresar_buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ingresar_buttonLayout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel5)
                .addContainerGap(30, Short.MAX_VALUE))
        );
        ingresar_buttonLayout.setVerticalGroup(
            ingresar_buttonLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(ingresar_buttonLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel5)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel3.add(ingresar_button, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 390, -1, -1));

        registrarse_label.setFont(new java.awt.Font("Tahoma", 1, 13)); // NOI18N
        registrarse_label.setText("Registrarse");
        registrarse_label.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                registrarse_labelMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                registrarse_labelMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                registrarse_labelMouseExited(evt);
            }
        });
        jPanel3.add(registrarse_label, new org.netbeans.lib.awtextra.AbsoluteConstraints(170, 350, -1, -1));

        jLabel2.setFont(new java.awt.Font("Yu Gothic Medium", 0, 12)); // NOI18N
        jLabel2.setText("¿No tienes una cuenta?");
        jPanel3.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(140, 330, -1, -1));

        usuarioTF.setBackground(new java.awt.Color(176, 176, 176));
        usuarioTF.setFont(new java.awt.Font("Yu Gothic Medium", 0, 13)); // NOI18N
        usuarioTF.setText("Ingresar su usuario");
        usuarioTF.setBorder(null);
        usuarioTF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                usuarioTFMouseClicked(evt);
            }
        });
        jPanel3.add(usuarioTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 200, 240, 30));

        contraTF.setBackground(new java.awt.Color(176, 176, 176));
        contraTF.setText("jPasswordField1");
        contraTF.setBorder(null);
        contraTF.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                contraTFMouseClicked(evt);
            }
        });
        jPanel3.add(contraTF, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 280, 240, 20));

        jLabel3.setFont(new java.awt.Font("Yu Gothic Medium", 0, 13)); // NOI18N
        jLabel3.setText("Usuario");
        jPanel3.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 170, -1, -1));

        jLabel4.setFont(new java.awt.Font("Yu Gothic Medium", 0, 13)); // NOI18N
        jLabel4.setText("Contraseña");
        jPanel3.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 250, -1, -1));
        jPanel3.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 300, 240, 10));
        jPanel3.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 230, 240, 10));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, 806, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 507, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void barra_tareasMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barra_tareasMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_barra_tareasMousePressed

    private void barra_tareasMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barra_tareasMouseDragged
        int x = evt.getXOnScreen();
        int y = evt.getYOnScreen();
        this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_barra_tareasMouseDragged

    private void barra_tareasMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_barra_tareasMouseEntered
        barra_tareas.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_barra_tareasMouseEntered

    private void cerrar_btnMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerrar_btnMouseClicked
        System.exit(0);
    }//GEN-LAST:event_cerrar_btnMouseClicked

    private void cerrar_btnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerrar_btnMouseEntered
        cerrar_btn.setBackground(new Color(195, 128, 250));
        cerrar_lbl.setForeground(Color.BLACK);
        cerrar_btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }//GEN-LAST:event_cerrar_btnMouseEntered

    private void cerrar_btnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerrar_btnMouseExited
        cerrar_btn.setBackground(new Color(127, 71, 173));
        cerrar_lbl.setForeground(new Color(245, 250, 186));
    }//GEN-LAST:event_cerrar_btnMouseExited

    private void ingresar_buttonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ingresar_buttonMouseClicked
        this.setVisible(false);
        vista2.setLocationRelativeTo(null);
        vista2.setVisible(true);
    }//GEN-LAST:event_ingresar_buttonMouseClicked

    private void ingresar_buttonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ingresar_buttonMouseEntered
        ingresar_button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        ingresar_button.setBackground(new Color(195, 128, 250));
        jLabel5.setForeground(Color.BLACK);
    }//GEN-LAST:event_ingresar_buttonMouseEntered

    private void ingresar_buttonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ingresar_buttonMouseExited
        ingresar_button.setBackground(new Color(127, 71, 173));
        jLabel5.setForeground(new Color(245, 250, 186));
    }//GEN-LAST:event_ingresar_buttonMouseExited

    private void registrarse_labelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarse_labelMouseClicked
        this.setVisible(false);
        vista.setLocationRelativeTo(null);
        vista.setVisible(true);
    }//GEN-LAST:event_registrarse_labelMouseClicked

    private void registrarse_labelMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarse_labelMouseEntered
        registrarse_label.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        Font font = registrarse_label.getFont();
        Font a = font;
        Map attributes = font.getAttributes();
        attributes.put(TextAttribute.UNDERLINE, TextAttribute.UNDERLINE_ON);
        registrarse_label.setFont(font.deriveFont(attributes));
    }//GEN-LAST:event_registrarse_labelMouseEntered

    private void registrarse_labelMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_registrarse_labelMouseExited
        registrarse_label.setFont(a);
    }//GEN-LAST:event_registrarse_labelMouseExited

    private void usuarioTFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_usuarioTFMouseClicked
        usuarioTF.setText("");
    }//GEN-LAST:event_usuarioTFMouseClicked

    private void contraTFMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_contraTFMouseClicked
        contraTF.setText("");
    }//GEN-LAST:event_contraTFMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(iniciar_sesion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(iniciar_sesion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(iniciar_sesion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(iniciar_sesion.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new iniciar_sesion().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel barra_tareas;
    private javax.swing.JPanel cerrar_btn;
    private javax.swing.JLabel cerrar_lbl;
    private javax.swing.JPasswordField contraTF;
    private javax.swing.JPanel ingresar_button;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    public javax.swing.JLabel registrarse_label;
    private javax.swing.JTextField usuarioTF;
    // End of variables declaration//GEN-END:variables
}
