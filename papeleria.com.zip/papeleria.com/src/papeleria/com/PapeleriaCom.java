/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package papeleria.com;

import view_controller.inicio_controller;

/**
 *
 * @author Jaider
 */
public class PapeleriaCom {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       inicio_controller controller = new inicio_controller();
       controller.iniciar();
    }
    
}
