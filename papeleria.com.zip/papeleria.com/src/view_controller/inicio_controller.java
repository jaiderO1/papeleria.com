/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view_controller;

import views.iniciar_sesion;


public class inicio_controller{

    iniciar_sesion vista;

    public inicio_controller() {
        this.vista=new iniciar_sesion();
    }
    public void iniciar(){
        this.vista.setLocationRelativeTo(null);
        this.vista.setVisible(true);
    }


}
